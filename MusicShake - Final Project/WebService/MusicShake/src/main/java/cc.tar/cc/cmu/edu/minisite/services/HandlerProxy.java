package cc.cmu.edu.minisite.services;

import cc.cmu.edu.minisite.database.DBAdapter;
import cc.cmu.edu.minisite.model.SongRecord;
import java.util.*;

public abstract class HandlerProxy {
	private DBAdapter adapter = null;
	
	public HandlerProxy() {
		adapter = new DBAdapter();
	}
	
	public List<SongRecord> getSongRecord(String pattern) {
		if (adapter == null) {
			return null;
		}
		return adapter.getSongRecord(pattern);
	}
}
