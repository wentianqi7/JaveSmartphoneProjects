package cc.cmu.edu.minisite.database;

import java.sql.*;

import cc.cmu.edu.minisite.model.SongRecord;
import cc.cmu.edu.minisite.util.Logger;
import java.util.*;

public class DBAdapter implements SongHandler, DBConstants {
	JDBCAdapter adapter = null;

	public DBAdapter() {
		adapter = new JDBCAdapter();
	}

	public boolean isAuth(String username, String password) {

		return false;
	}

	@Override
	public List<SongRecord> getSongRecord(String pattern) {
		if (adapter == null) {
			return null;
		}
		List<SongRecord> srList = new LinkedList<SongRecord>();
		try {
			ResultSet rs = adapter.executeReadQuery(String.format(
					SELECT_SONG_URL, pattern, pattern));
			while (rs.next()) {
				SongRecord sr = new SongRecord(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getInt(7));
				srList.add(sr);
			}
			adapter.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return srList;
	}
}