package cc.cmu.edu.minisite.services;

import cc.cmu.edu.minisite.database.SongHandler;

public class RequsetHandler extends HandlerProxy implements SongHandler {

}
