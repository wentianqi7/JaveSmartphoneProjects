package cc.cmu.edu.minisite.database;

public interface DBConstants {
	String SQL_FILE = "query.txt";
	String DRIVER = "com.mysql.jdbc.Driver";
	String URL = "jdbc:mysql://127.0.0.1/test";
	String USERNAME = "root";
	String PASSWORD = "15319project";

	String SELECT_SONG_URL = "select * from songs where name like "
			+ "\"%%%s%%\" or singer like \"%%%s%%\";";
}
